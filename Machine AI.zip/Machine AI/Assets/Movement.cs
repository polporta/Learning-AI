﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This class is used to give the AI it's values to move
[Serializable]
public class MovementData
{
    public float speed;
    public float jumpForce;
    public float distanceAI;
}
public class Movement : MonoBehaviour {

    public GAManager gAManager;

    // Variables to help us move the AI
    public Rigidbody2D rb;
    public bool canJump;
    public bool isDead;
    public bool finished;
    public MovementData movementData = new MovementData();
    Transform start;
    //States for the AI to use
    public enum State
    {
        Jump,
        Run
    }
    //Variable to change states
    public State state;

	// Use this for initialization
	void Start () {
        //Get the rigidbody to move it and the transform of the start to reset the AI position
        rb = GetComponent<Rigidbody2D>();
        start = GameObject.Find("Start").GetComponent<Transform>();
        //The initial state
        state = State.Run;
	}
	
	// Update is called once per frame
	void Update () {
        //Here is where we switch states and what every state does
        switch (state)
        {
            case State.Jump:
                {
                    Jump();
                    break;
                }
            case State.Run:
                {
                    Run();
                    break;
                }
        } 
	}

    void Jump()
    {
        //we add some upward force to the rb to jump, the AI starts randomly selecting the jumpforce, but the more it evolves the more accurately it chooses
        if(canJump == true)
            rb.AddForce(Vector3.up * movementData.jumpForce, ForceMode2D.Force);
    }

    void Run()
    {
        //we add some force to the right so the rb moves, the AI starts randomly selecting the speed, but the more it evolves the more accurately it chooses
        //rb.AddForce(Vector3.right * movementData.speed, ForceMode2D.Force);
        rb.velocity = Vector3.right * movementData.speed;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        // if it collides with this collider the boolean will became true
        if (collision.collider.tag == "Floor")
        {
            canJump = true;
            state = State.Run;
        }
        // If it collides with the finish line it has succeded
        if (collision.collider.tag == "TheEnd")
        {
            finished = true;
            gAManager.Succes();
        }

    }


    void OnTriggerEnter2D(Collider2D other)
    {
        //if it hits this trigger and the boolean is true the state will change
        if (other.tag == "AddScore" && canJump == true)
        {
            state = State.Jump;
           // Debug.Log("Increase Score");
        }
        //if it hits this trigger it will restart its position and set the boolean true
        if (other.tag == "DecreaseScore")
        {
           // Debug.Log("Decrease Score");
            this.transform.position = start.position;
            isDead = true;
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        // if it leaves the trigger the boolean will become false and the state will change
        if (collision.tag == "AddScore")
        {
            canJump = false;
        }
        //if it leaves the trigger the boolean is set to false
        if (collision.tag == "DecreaseScore")
        {
            isDead = false;
        }
    }
}
