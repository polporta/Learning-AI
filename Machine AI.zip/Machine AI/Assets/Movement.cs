﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MovementData
{
    public float speed;
    public float jumpForce;
    public float distanceAI;
    public int triggersHad;
}

public class Movement : MonoBehaviour {

    public Rigidbody rb;
    public float gravity;
    public MovementData movementData;

    private GeneticAlgorithm<MovementData> ga;


	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();

	}
	
	// Update is called once per frame
	void Update () {

        Jump();
        Run();
	}

    void Jump()
    {
        rb.AddForce(Vector3.up * movementData.jumpForce, ForceMode.Impulse);
        rb.AddForce(Physics.gravity * gravity, ForceMode.Acceleration);
    }

    void Run()
    {
        rb.AddForce(Vector3.right * movementData.speed, ForceMode.Force);
    }
}
