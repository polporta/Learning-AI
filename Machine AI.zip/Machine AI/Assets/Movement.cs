﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This class is used to give the AI it's values to move
[Serializable]
public class MovementData
{
    public float speed;
    public float jumpForce;
    public float distanceAI;
}

public class Movement : MonoBehaviour {
    // Variables to help us move the AI
    public Rigidbody2D rb;
    public bool canJump;
    public MovementData movementData;
    Transform start;
    //Reference to the GeneticAlgorithm script
    private GeneticAlgorithm<MovementData> ga;
    //States for the AI to use
    public enum State
    {
        Jump,
        Run
    }
    //Variable to change states
    public State state;

	// Use this for initialization
	void Start () {
        //Get the rigidbody to move it and the transform of the start to reset the AI position
        rb = GetComponent<Rigidbody2D>();
        start = GameObject.Find("Start").GetComponent<Transform>();
        //The initial state
        state = State.Run;
	}
	
	// Update is called once per frame
	void Update () {
        //Here is where we switch states and what every state does
        switch (state)
        {
            case State.Jump:
                {
                    Jump();
                    break;
                }
            case State.Run:
                {
                    Run();
                    break;
                }
        } 
	}

    void Jump()
    {
        //we add some upward force to the rb to jump, the AI starts randomly selecting the jumpforce, but the more it evolves the more accurately it chooses
        rb.AddForce(Vector3.up * movementData.jumpForce, ForceMode2D.Impulse);
    }

    void Run()
    {
        //we add some force to the right so the rb moves, the AI starts randomly selecting the speed, but the more it evolves the more accurately it chooses
        rb.AddForce(Vector3.right * movementData.speed, ForceMode2D.Force);
    }


    void OnTriggerEnter2D(Collider2D other)
    {
        //if it hits this trigger and the boolean is true the state will change
        if (other.tag == "AddScore" && canJump == true)
        {
            state = State.Jump;
            Debug.Log("Increase Score");
        }
       // if it hits this trigger the boolean will became true
        if (other.tag == "Floor")
        {
            canJump = true;
        }
        //if it hits this trigger it will restart its position and make a new generation
        if (other.tag == "DecreaseScore")
        {
            Debug.Log("Decrease Score");
            this.transform.position = start.position;
           // ga.NewGeneration();
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        // if it leaves the trigger the boolean will become false and the state will change
        if (collision.tag == "AddScore")
        {
            canJump = false;
            state = State.Run;
        }
    }
}
