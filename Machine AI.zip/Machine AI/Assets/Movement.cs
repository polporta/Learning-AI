﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MovementData
{
    public float speed;
    public float jumpForce;
    public float distanceAI;
    public int triggersHad;
}

public class Movement : MonoBehaviour {

    public Rigidbody rb;
    public float gravity;
    public bool hasJumped;
    public MovementData movementData;

    private GeneticAlgorithm<MovementData> ga;

    public enum State
    {
        Jump,
        Run
    }

    public State state;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();

        state = State.Run;
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetButtonDown("Jump"))
        {
            state = State.Jump;
        }
        else if(Input.GetButtonUp("Jump"))
        {
                state = State.Run;
        }

        switch (state)
        {
            case State.Jump:
                {
                    Jump();
                    break;
                }
            case State.Run:
                {
                    Run();
                    break;
                }
        } 
	}

    void Jump()
    {
        rb.AddForce(Vector3.up * movementData.jumpForce, ForceMode.Impulse);
        rb.AddForce(Physics.gravity * gravity, ForceMode.Acceleration);
        hasJumped = true;
    }

    void Run()
    {
        rb.AddForce(Vector3.right * movementData.speed, ForceMode.Force);
        hasJumped = false;
    }

}
