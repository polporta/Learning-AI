﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GAManager : MonoBehaviour {

    private GeneticAlgorithm<MovementData> ga;
	private System.Random random;
    public Movement movement;
    DataDisplay data;

    //Movement Variables
    Movement movementData;
    Transform finish;
	Transform start;
	float distance;
    int maxSpeed = 20;
    int minSpeed = 1;
    //through testing these values are the ones more likely to work
    int maxJump = 500;
    int minJump = 80;

    //Genetic Algorithm variables
    public int populationSize = 5;
    public int elitism = 2;
    public float mutationRate = 0.01f;
    public int dnaSize = 1;
    public int currentPopulation = 0;
    public int currentGeneIndex = 0;


    // We find the transforms of the start and finish and calculate the distance between them, we get the movement script from the AI too, as well as referencing the System Random and the Genetic algorithm
    //Also we dont want to destroy our data recorder
    void Start () {
        data = GameObject.Find("DataManager").GetComponent<DataDisplay>();
        finish = GameObject.Find("Finish").GetComponent<Transform>();
        start = GameObject.Find("Start").GetComponent<Transform>();
        movementData = GameObject.Find("Capsule").GetComponent<Movement>();
        distance = Vector3.Distance(start.position, finish.position);
        random = new System.Random();
		ga = new GeneticAlgorithm<MovementData>(populationSize, dnaSize, random, GetRandomMovement, FitnessFunction, elitism, mutationRate);
        StartSimulation();

    }
	
	// Update is called once per frame
	void Update () {
        // if the AI is dead it will go to the next simulation
        if(movement.isDead == true)
        {
            NextSimulation();
        }
	}

	public MovementData GetRandomMovement ()
	{
        //Generates the random movement values for the AI
        MovementData movementData = new MovementData();
	    movementData.speed = Random.Range (minSpeed, maxSpeed);
		movementData.jumpForce = Random.Range(minJump, maxJump);
        return movementData;
	}

	private float FitnessFunction(int index)
	{
        //This calculate the score that the AI got
		float score = 0;
		DNA<MovementData> dna = ga.Population [index];

		for (int i = 0; i < dna.Genes.Length; i++) 
		{
                score += distance-dna.Genes[i].distanceAI;
		}
        Debug.Log(score);
        return score;
	}
    // starts the simulation by going trhough all the population and the gene
    public void StartSimulation()
    {
        DNA<MovementData> dna = ga.Population[currentPopulation];
        MovementData currentGene = dna.Genes[currentGeneIndex];
        movement.movementData = currentGene;
    }
    // the next simulation restarts when a population has died until it goes trhough all the populations
    public void NextSimulation()
    {
        float distance=Vector3.Distance(transform.position, finish.position);
        DNA<MovementData> dna = ga.Population[currentPopulation];
        MovementData currentGene = dna.Genes[currentGeneIndex];
        currentGene.distanceAI = distance;

       currentPopulation++;
        currentGeneIndex = 0;
        if (currentPopulation >= populationSize)
        {
            //when it has gone trhough all the populations it will go to the next generation
            currentPopulation = 0;
            ga.NewGeneration();
        }


        dna = ga.Population[currentPopulation];
        currentGene = dna.Genes[currentGeneIndex];
        movement.movementData = currentGene;
    }
    // if it has succeded it will go to the next scene and display the values of that AI
    public void Succes()
    {
        DontDestroyOnLoad(data);
        SceneManager.LoadScene("SuccesfullAI");
    }
}
