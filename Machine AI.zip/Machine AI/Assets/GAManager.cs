﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GAManager : MonoBehaviour {

    private GeneticAlgorithm<MovementData> ga;
	private System.Random random;

    //Movement
    Transform finish;
	Transform start;
	float xstart;
	float xfinish;
	int distance;
    int topScore = 15;
    int maxSpeed = 15;
    int minSpeed = 1;
    int maxJump = 15;
    int minJump = 1;

    //Genetic Algorithm
    public int populationSize = 1;
    int elitism = 2;
    float mutationRate = 0.01f;
    int dnaSize = 10;

    // Use this for initialization
    void Start () {
        finish = GameObject.Find("Finish").GetComponent<Transform>();
        start = GameObject.Find("Start").GetComponent<Transform>();
		xstart = start.position.x;
		xfinish = finish.position.y;
		distance = (int)xstart - (int)xfinish;
        random = new System.Random();
		ga = new GeneticAlgorithm<MovementData>(populationSize, dnaSize, random, GetRandomMovement, FitnessFunction, elitism, mutationRate);
	}
	
	// Update is called once per frame
	void Update () {

	}

	public MovementData GetRandomMovement ()
	{
        MovementData movementData = new MovementData();
	movementData.speed = Random.Range (minSpeed, maxSpeed);
		movementData.jumpForce = Random.Range(minJump, maxJump);
		return movementData;
	}

	private float FitnessFunction(int index)
	{
		float score = 0;
		DNA<MovementData> dna = ga.Population [index];

		for (int i = 0; i < dna.Genes.Length; i++) 
		{
			if (dna.Genes [i].distanceAI == distance)
			{
				score += 1;
			}

            score += dna.Genes[i].triggersHad / topScore;
		}

        return score;
	}

	void OnTriggerEnter(Collider other)
	{
		MovementData movetriggers = new MovementData ();
		if (other.tag == "AddScore") {
            Debug.Log("Increase Score");
            movetriggers.triggersHad++;
		} else if (other.tag == "DecreaseScore") {
            Debug.Log("Decrease Score");
            this.transform.position = start.position;
            ga.NewGeneration();
		}
	}

}
