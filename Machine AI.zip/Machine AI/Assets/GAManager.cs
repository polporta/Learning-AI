﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GAManager : MonoBehaviour {

    private GeneticAlgorithm<MovementData> ga;
	private System.Random random;
    public Movement movement;

    //Movement Variables
    Movement movementData;
    Transform finish;
	Transform start;
	float distance;
   // int topScore = 15;
    int maxSpeed = 15;
    int minSpeed = 5;
    int maxJump = 400;
    int minJump = 50;

    //Genetic Algorithm variables
    public int populationSize = 5;
    public int elitism = 2;
    public float mutationRate = 0.01f;
    public int dnaSize = 1;
    public int currentPopulation = 0;
    public int currentGeneIndex = 0;


    // We find the transforms of the start and finish and calculate the distance between them as well as referencing the System Random and the Genetic algorithm
    void Start () {
        finish = GameObject.Find("Finish").GetComponent<Transform>();
        start = GameObject.Find("Start").GetComponent<Transform>();
        movementData = GameObject.Find("Capsule").GetComponent<Movement>();
        distance = Vector3.Distance(start.position, finish.position);
        random = new System.Random();
		ga = new GeneticAlgorithm<MovementData>(populationSize, dnaSize, random, GetRandomMovement, FitnessFunction, elitism, mutationRate);
        StartSimulation();

    }
	
	// Update is called once per frame
	void Update () {
        if(movement.isDead == true)
        {
            NextSimulation();
        }
	}

	public MovementData GetRandomMovement ()
	{
        //Generates the random movement values for the AI
        MovementData movementData = new MovementData();
	    movementData.speed = Random.Range (minSpeed, maxSpeed);
       // Debug.Log(movementData.speed);
		movementData.jumpForce = Random.Range(minJump, maxJump);
       // Debug.Log(movementData.speed);
        return movementData;
	}

	private float FitnessFunction(int index)
	{
        //This calculate the score that the AI got
		float score = 0;
		DNA<MovementData> dna = ga.Population [index];

		for (int i = 0; i < dna.Genes.Length; i++) 
		{


                score += distance-dna.Genes[i].distanceAI;


            //score += dna.Genes[i].triggersHad / topScore;
		}
        Debug.Log(score);
        return score;
	}

    public void StartSimulation()
    {
        DNA<MovementData> dna = ga.Population[currentPopulation];
        MovementData currentGene = dna.Genes[currentGeneIndex];
        movement.movementData = currentGene;
    }

    public void NextSimulation()
    {
        float distance=Vector3.Distance(transform.position, finish.position);
        DNA<MovementData> dna = ga.Population[currentPopulation];
        MovementData currentGene = dna.Genes[currentGeneIndex];
        currentGene.distanceAI = distance;

       currentPopulation++;
        currentGeneIndex = 0;
        if (currentPopulation >= populationSize)
        {
            currentPopulation = 0;
            ga.NewGeneration();
        }


        dna = ga.Population[currentPopulation];
        currentGene = dna.Genes[currentGeneIndex];
        movement.movementData = currentGene;
    }

    public void Succes()
    {
        Time.timeScale = 0;
    }
}
