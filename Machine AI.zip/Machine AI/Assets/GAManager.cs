﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GAManager : MonoBehaviour {

    private GeneticAlgorithm<MovementData> ga;
	private System.Random random;

    Transform finish;
    float distance;
    public int populationSize = 1;
    int dnaSize;
    int elitism = 1;
    int topScore = 15;
    float maxSpeed = 15;
    float minSpeed = 1;
    float maxJump = 15;
    float minJump = 1;
    float mutationRate = 0.01f;

    // Use this for initialization
    void Start () {
        finish = GameObject.Find("Finish").GetComponent<Transform>();
        distance = finish.position;
		ga = new GeneticAlgorithm<MovementData>(populationSize, dnaSize, random, GetRandomMovement, FitnessFunction, elitism, mutationRate);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public MovementData GetRandomMovement ()
	{
        MovementData movementData = new MovementData();
	movementData.speed = Random.Range (minSpeed, maxSpeed);
		movementData.jumpForce = Random.Range(minJump, maxJump);
		return movementData;
	}

	private float FitnessFunction(int index)
	{
		float score = 0;
		DNA<MovementData> dna = ga.Population [index];

		for (int i = 0; i < dna.Genes.Length; i++) 
		{
			if (dna.Genes [i].distanceAI == distance) 
			{
				score += 1;
			}

            score += dna.Genes[i].triggersHad / topScore;
		}

        return score;
	}

}
