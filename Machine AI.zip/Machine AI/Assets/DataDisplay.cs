﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DataDisplay : MonoBehaviour {
    //we get the variables to display the values of the AI
    public GAManager gAManager;
    public Text speedText, jumpText;
    float finalSpeed;
    float finalJumpForce;

    void Awake()
    {
        //when the script awakes it calls on the function
        DisplayText();
    }

    void Update()
    {
        // it gets the values from the AI and diplays them
            finalSpeed = gAManager.movement.movementData.speed;
            finalJumpForce = gAManager.movement.movementData.jumpForce;
            speedText.text = "Best Speed " + finalSpeed;
            jumpText.text = "Best Jump Force " + finalJumpForce;

    }

    void DisplayText()
    {
        // finds the texts where to display the values
        speedText = GameObject.Find("BestSpeed").GetComponent<Text>();
        jumpText = GameObject.Find("BestJump").GetComponent<Text>();

    }
}
