﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MovementData
{
    public float speed;
    public float jumpForce;
    public float distanceAI;
    public int triggersHad;
}

public class Movement : MonoBehaviour {

    public Rigidbody2D rb;
    public bool canJump;
    public MovementData movementData;
    Transform start;

    private GeneticAlgorithm<MovementData> ga;

    public enum State
    {
        Jump,
        Run
    }

    public State state;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody2D>();
        start = GameObject.Find("Start").GetComponent<Transform>();

        state = State.Run;
	}
	
	// Update is called once per frame
	void Update () {

        switch (state)
        {
            case State.Jump:
                {
                    Jump();
                    break;
                }
            case State.Run:
                {
                    Run();
                    break;
                }
        } 
	}

    void Jump()
    {
        rb.AddForce(Vector3.up * movementData.jumpForce, ForceMode2D.Impulse);
    }

    void Run()
    {
        rb.AddForce(Vector3.right * movementData.speed, ForceMode2D.Force);
    }


    void OnTriggerEnter2D(Collider2D other)
    {
        //MovementData movetriggers = new MovementData();
        if (other.tag == "AddScore" && canJump == true)
        {
            state = State.Jump;
            Debug.Log("Increase Score");
            //movetriggers.triggersHad++;
        }
        if (other.tag == "Floor")
        {
            canJump = true;
        }
        if (other.tag == "DecreaseScore")
        {
            Debug.Log("Decrease Score");
            this.transform.position = start.position;
           // ga.NewGeneration();
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "AddScore")
        {
            canJump = false;
            state = State.Run;
        }
    }
}
