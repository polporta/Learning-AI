﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GAManager : MonoBehaviour {

    private GeneticAlgorithm<MovementData> ga;
	private System.Random random;
    public Movement movement;

    //Movement
    Transform finish;
	Transform start;
	float distance;
    int topScore = 15;
    int maxSpeed = 15;
    int minSpeed = 1;
    int maxJump = 15;
    int minJump = 1;

    //Genetic Algorithm
    public int populationSize = 5;
    public int elitism = 2;
    public float mutationRate = 0.01f;
    public int dnaSize = 10;

    // Use this for initialization
    void Start () {
        finish = GameObject.Find("Finish").GetComponent<Transform>();
        start = GameObject.Find("Start").GetComponent<Transform>();
		distance = Vector3.Distance(start.position, finish.position);
        random = new System.Random();
		ga = new GeneticAlgorithm<MovementData>(populationSize, dnaSize, random, GetRandomMovement, FitnessFunction, elitism, mutationRate);
	}
	
	// Update is called once per frame
	void Update () {

	}

	public MovementData GetRandomMovement ()
	{
        MovementData movementData = new MovementData();
	    movementData.speed = Random.Range (minSpeed, maxSpeed);
		movementData.jumpForce = Random.Range(minJump, maxJump);
		return movementData;
	}

	private float FitnessFunction(int index)
	{
		float score = 0;
		DNA<MovementData> dna = ga.Population [index];

		for (int i = 0; i < dna.Genes.Length; i++) 
		{
           float currentDistance = Vector3.Distance(transform.position, finish.position);
  
				score += distance-currentDistance;


            score += dna.Genes[i].triggersHad / topScore;
		}

        return score;
	}

    public void StartSimulation()
    {

    }
}
