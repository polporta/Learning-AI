﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

    public Rigidbody rb;
    public float speed;
    public float jumpForce;
    public bool hasJumped;

    public enum State
    {
        Jump,
        Run
    }

    public State state;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();

        state = State.Run;
	}
	
	// Update is called once per frame
	void Update () {

        switch(state)
        {
            case State.Jump:
                {
                    Jump();
                    break;
                }
            case State.Run:
                {
                    Run();
                    break;
                }
        } 
	}

    void Jump()
    {
        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        hasJumped = true;
    }

    void Run()
    {
        rb.AddForce(Vector3.right * speed, ForceMode.Force);
        hasJumped = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Obstacle")
        {
            state = State.Jump;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Obstacle")
        {
            state = State.Run;
        }
    }
}
